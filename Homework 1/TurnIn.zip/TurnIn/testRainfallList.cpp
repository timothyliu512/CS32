//
//  testRainfallList.cpp
//  Homework 1
//
//  Created by Timothy Liu on 4/17/23.
//

#include <iostream>
#include <cassert>
#include "RainfallList.h"

int main() {
    return 0;
}



