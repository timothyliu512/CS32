//
//  testSequence.cpp
//  Homework 1
//
//  Created by Timothy Liu on 4/13/23.
//

#include <iostream>
#include "Sequence.h"

using namespace std;

int main() {
    return 0;
}
