//
//  testnewSequence.cpp
//  Homework 1
//
//  Created by Timothy Liu on 4/17/23.
//

#include "newSequence.h"
#include <iostream>
#include <cassert>

int main()
{
    return 0;
}

//Since the compiler-generated destructor, copy constructor, and assignment operator no longer do the right thing, declare them (as public members) and implement them. Make no other changes to the public interface of your class. (You are free to make changes to the private members and to the implementations of the member functions, and you may add or remove private members.) Change the implementation of the swap function so that the number of statement executions when swapping two sequences is the same no matter how many items are in the sequences. (You would not satisfy this requirement if, for example, your swap function caused a loop to visit each item in the sequences, since the number of statements executed by all the iterations of the loop would depend on the number of items in the sequences.)
