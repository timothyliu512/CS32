//
//  event.cpp
//  Homework 3
//
//  Created by Timothy Liu on 5/3/23.
//

class Event
{
public:
    Event(const string& name) : mName(name)
    {
    }
    
    string name() const
    {
        return mName;
    }
    
    virtual string need() const = 0;
    
    virtual bool isSport() const {
        return true;
    }
    
    virtual ~Event() {}
    
private:
    string mName;
};



class Concert : public Event
{
public:
    Concert(const string& name, const string& genre) : Event(name),  mGenre(genre)
    {
        
    }
    
    virtual string need() const
    {
        return "a stage";
    }
    
    virtual bool isSport() const {
        return false;
    }
    
    virtual ~Concert() {
        cout << "Destroying the " << name() << " " << mGenre << " concert" << endl;
    }
    
    string genre() const { return mGenre; };
    
private:
    string mGenre;
};



class BasketballGame : public Event
{
public:
    BasketballGame(const string& name) : Event(name)
    {
        
    }
    
    virtual string need() const
    {
        return "hoops";
    }
    
    virtual ~BasketballGame() {
        cout << "Destroying the " << name() << " basketball game" << endl;
    }
    
private:
    
};



class HockeyGame : public Event
{
public:
    
    HockeyGame(const string& name) : Event(name)
    {
        
    }
    
    virtual string need() const
    {
        return "ice";
    }
    
    virtual ~HockeyGame() {
        cout << "Destroying the " << name() << " hockey game" << endl;
    }
    
private:
};
