//
//  linear.cpp
//  Homework 3
//
//  Created by Timothy Liu on 5/6/23.
//

bool allTrue(const string a[], int n)
{
    if ( n <= 0 )
    {
        return true;
    }
    
    
    if( somePredicate( a[n-1] ) == false )
    {
        return false;
    }
    
    else
    {
        return allTrue( a , n-1 );
    }
}

int countTrue(const string a[], int n)
{
    if ( n <= 0 )
    {
        return 0;
    }
    
    if ( somePredicate(a[n-1]) )
    {
        return countTrue( a, n-1 ) + 1;
    }
        
    else
    {
        return countTrue( a, n-1 );
    }
}

int firstTrue(const string a[], int n)
{
    if ( n <= 0 )
    {
        return -1;
    }
    
    if ( n == 1 )
    {
        if (somePredicate(a[0]))
        {
            return 0;
        }
        else
        {
            return -1;
        }
        
    }

    if ( firstTrue(a, n-1) == -1 )
    {
        if ( somePredicate(a[n-1]))
        {
            return n-1;
        }
    
        else
        {
            return -1;
        }
    }
    
    return firstTrue(a, n - 1);
    
}

int positionOfMax(const string a[], int n)
{
    if ( n <= 0 )
    {
        return -1;
    }
    
    if ( n == 1 )
    {
        return 0;
    }
    
    int maxPos = positionOfMax(a, n-1);
    
    if( a[maxPos] < a[n-1] )
    {
        return n-1;
    }
    else
    {
        return maxPos;
    }
}

bool contains(const string a1[], int n1, const string a2[], int n2)
{
    
    if ( n2 > n1 )
    {
        return false;
    }
    
    if( (n2 == 0 && n1 == n2) ||  (n2 <= 0) )
    {
        return true;
    }
    
    if (a1[n1-1] == a2[n2-1])
    {
        return contains(a1, n1-1, a2, n2-1);
    }
    else
    {
        return contains(a1, n1-1, a2, n2);
    }
    
}
