//
//  Side.hpp
//  Project3
//
//  Created by Timothy Liu on 5/16/23.
//

#ifndef SIDE_H
#define SIDE_H

#include <stdio.h>


enum Side { NORTH, SOUTH };
const int NSIDES = 2;
const int POT = 0;

#endif /* SIDE_H */
